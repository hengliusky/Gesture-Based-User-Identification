#ifndef DTW_H
#define DTW_H
#include "global.h"
class DTW
{
public:
	DTW();
	~DTW();

public:
	void SetInputTrack(std::vector<std::vector<point3d>> InputTrack);
	void SetTemplateNum(int userNum, int gestureNum, int templateNum);
	int GetGestureID();
	int GetUserID();
private:
	std::vector<std::vector<point3d>> m_inputTrack;
	std::vector<std::vector<std::vector<point3d>>> m_templateTrack;
	std::string m_templatePath;
	int m_nTemplateNum;
	int m_nGestureNum;
	int m_nUserNum;
	int m_nGestureID;
	int m_nUserID;

private:
	void __Init();
	void __SetTemplateTrack();
	void __DTWAlgorithm();
	void __UpdateTemplateTrack();
};


#endif