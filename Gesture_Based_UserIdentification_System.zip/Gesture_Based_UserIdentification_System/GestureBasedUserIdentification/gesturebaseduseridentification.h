#ifndef GESTUREBASEDUSERIDENTIFICATION_H
#define GESTUREBASEDUSERIDENTIFICATION_H

#include <QtWidgets/QMainWindow>
#include "ui_gesturebaseduseridentification.h"
#include <qlabel.h>
#include <QMouseEvent> //���������ͷ�ļ�
#include <QPushButton> //���ð�ť��ͷ�ļ�
#include <qtimer.h>
#include <global.h>
#include "CKinectSensor.h"
#include "DTW.h"
#include <string>
#include <QComboBox>
#include "resultshow.h"

class GestureBasedUserIdentification : public QMainWindow
{
	Q_OBJECT

public:
	GestureBasedUserIdentification(QWidget *parent = 0);
	~GestureBasedUserIdentification();

private:
	Ui::GestureBasedUserIdentificationClass ui;

private:
	QLabel *labelTitle;
	QLabel *labelVideo;
	QLabel *labelStatus;
	QLabel *labelChoose;
	QPushButton *buttonClose;
	QPushButton *buttonOpen;
	QPushButton *buttonStop;
	QComboBox *comboBox;
	QPoint last;
	QImage imageFeame;
	QTimer *timer;
	CKinectSensor *pKinectSensor;
	bool isCameraOpened = false;
	ResultShow w2;


	void init();
	void setLabelChoose();
	void setComboBox();
	void setWindowStyle();
	void setLabelTitle();
	void setButtonClose();
	void setLabelVideo();
	void setLabelStatus();
	void setButtonOpen();
	void setButtonStop();
	void showResultWindow();
	QImage  Mat2QImage(cv::Mat cvImg);
signals:
	void explains();
	void sedResultWindTxt();

//
private slots:
	void startCapture();
	void stopCapture();
	void nextFrame();
	void closeResultWindow();

protected:
	//��갴��
	void mousePressEvent(QMouseEvent *e);
	//����ƶ�
	void mouseMoveEvent(QMouseEvent *e);
	//����ͷ�
	void mouseReleaseEvent(QMouseEvent *e);
	//���� QPoint ����


private:
	cv::Mat frame;
	DTW *pDTW = new DTW();
	struct fann *ann = fann_create_from_file("./Resources/ann.net");
	std::vector<std::vector<point3d>> bodyDataSequence;//�ؽ���Ϣ���У�5֡���棩
	std::vector<std::vector<point3d>> gestureSequence;//��������
	std::vector<std::vector<point3d>> gestureSourceSequence;//��������

	int startFrameNum = 5;//���ƿ�ʼ��������С
	int finishFrameNum = 10;//���ƽ�����������С
	int readyFrameNum = 30;//����׼��
	int startFramCount = 0;
	int finishFrameCount = 0;
	int readyFrameCount = 0;
	int frameCount = 0;//ͼ��֡��
	int bodyCount = 1;//�ؽ���Ϣ��
	bool isGestureStart = false;
	bool isGestureFinished = false;
	bool isGestureReady = false;
	int gestureStatus = -1;
	int UserID = -1;
	int GestureID = -1;
	bool isIdentify = true;//ture=ʶ��false=�ɼ�
	bool isDataCollect = false;
	std::vector<std::string> UserName;
	std::vector<std::string> GestureName;
	int userNum;
	int gestureNum;
	std::vector<point3d> dataNormalization(std::vector<std::vector<point3d>>  bodyDataSequence);
	std::vector<point3d> GaussianSmooth(std::vector<std::vector<point3d>> bodyDataSequence);
	int mGestureStatus(struct fann *ann, std::vector<point3d> bodydata, cv::Mat &frame, std::vector<point2d> body2dCoord);
	int gestureStatusForShow =1;
};

#endif // GESTUREBASEDUSERIDENTIFICATION_H
