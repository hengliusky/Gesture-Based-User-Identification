#include "gesturebaseduseridentification.h"
#include <QMessageBox> 
#include <fstream> 

using namespace cv;
using namespace std;
GestureBasedUserIdentification::GestureBasedUserIdentification(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);
	setWindowStyle();
	setLabelTitle();
	setButtonClose();
	connect(buttonClose, SIGNAL(clicked()), this, SLOT(close()));
	setLabelVideo();
	setButtonOpen();
	setButtonStop();
	setLabelStatus();
	setComboBox();
	setLabelChoose();
	connect(buttonOpen, SIGNAL(clicked()), this, SLOT(startCapture()));
	connect(buttonStop, SIGNAL(clicked()), this, SLOT(stopCapture()));
	connect(this, SIGNAL(sedResultWindTxt()), &w2, SLOT(refreshLableTitle()));

}

GestureBasedUserIdentification::~GestureBasedUserIdentification()
{
}

void GestureBasedUserIdentification::init(){
	bodyDataSequence.clear();//�ؽ���Ϣ���У�5֡���棩
	gestureSequence.clear();;//��������
	gestureSourceSequence.clear();;//��������;
	startFrameNum = 5;//���ƿ�ʼ��������С
	finishFrameNum = 10;//���ƽ�����������С
	readyFrameNum = 30;//����׼��
	startFramCount = 0;
	finishFrameCount = 0;
	readyFrameCount = 0;
	frameCount = 0;//ͼ��֡��
	bodyCount = 1;//�ؽ���Ϣ��
	isGestureStart = false;
	isGestureFinished = false;
	isGestureReady = false;
	gestureStatus = -1;
	UserID = -1;
	GestureID = -1;
	gestureStatusForShow = 1;


}

//���ô�������
void GestureBasedUserIdentification::setWindowStyle(){
	this->setWindowFlags(Qt::FramelessWindowHint);
	this->setWindowIcon(QIcon("./Resources/image/title.jpg"));
	this->setMaximumSize(1600, 900);
	this->setMinimumSize(1600, 900);
	this->setStyleSheet("background:#cde6c7; border: 1px solid #00a6ac;");
	pKinectSensor = new CKinectSensor();
}

//���ñ�������
void GestureBasedUserIdentification::setLabelTitle(){
	labelTitle = new QLabel(this);
	labelTitle->setText("GestureBasedUserIdentification - Lab 207");
	labelTitle ->setGeometry(QRect(0, 0, 1551, 50));
	QFont    font("Times", 16, 75);    //��һ�����������壨΢���źڣ����ڶ����Ǵ�С���������ǼӴ֣�Ȩ����75��
	labelTitle->setFont(font);
	labelTitle->setStyleSheet("background:#008792;");
}

//��������������
void GestureBasedUserIdentification::setComboBox(){
	ifstream readUserName("./Resources/userName.txt");
	if (readUserName) // �и��ļ�  
	{
		string nameBuf;
		while (getline(readUserName, nameBuf)) // line�в�����ÿ�еĻ��з�  
		{
			UserName.push_back(nameBuf);
		}
	}
	userNum = UserName.size();

	ifstream readGestureName("./Resources/gestureName.txt");
	if (readGestureName) // �и��ļ�  
	{
		string gestureNameBuf;
		while (getline(readGestureName, gestureNameBuf)) // line�в�����ÿ�еĻ��з�  
		{
			GestureName.push_back(gestureNameBuf);
		}
	}
	gestureNum = GestureName.size();
	pDTW->SetTemplateNum(userNum, gestureNum, 3);

	comboBox = new QComboBox(this);
	comboBox->setGeometry(QRect(1300, 600, 200, 50));
	QFont    font("Times", 14, 25);    //��һ�����������壨΢���źڣ����ڶ����Ǵ�С���������ǼӴ֣�Ȩ����75��
	comboBox->setFont(font);
	//comboBox->setStyleSheet("QComboBox{background-color:#11264f; color:white;border:1px solid gray;selection-background-color: red;selection-color:black}"
	//	"QComboBox QAbstractItemView::item{height:40px; }"); //������ť
	comboBox->setStyleSheet("QComboBox{background-color:white;selection-background-color: white}");
	comboBox->addItem(tr("Admin"));
	for(int i = 0; i < UserName.size(); i++ ){
		comboBox->addItem(QString::fromStdString(UserName[i]));
	}
}

void GestureBasedUserIdentification::setLabelChoose(){
	labelChoose = new QLabel(this);
	labelChoose->setText("Access permission: ");
	labelChoose->setGeometry(QRect(1050, 600, 220, 50));
	QFont    font("Times", 14, 50);
	labelChoose->setFont(font);
	labelChoose->setStyleSheet("background:white; color:black");
}

//���ùرհ�ť����
void GestureBasedUserIdentification::setButtonClose(){
	buttonClose = new QPushButton(this);
	buttonClose->setText("X");
	QFont    font("Microsoft YaHei", 18, 75);
	buttonClose->setFont(font);
	buttonClose->setGeometry(QRect(1550, 0, 50, 50));

	buttonClose->setStyleSheet("QPushButton{background-color:#145b7d; color:black}"
		"QPushButton:hover{background-color:#aa2116; color: black;}"
		"QPushButton:pressed{background-color:#aa2116;color: black }");
}

//������Ƶ��ʾ������
void GestureBasedUserIdentification::setLabelVideo(){
	labelVideo = new QLabel(this);
	labelVideo->setGeometry(QRect(50, 100, 960, 540));
	this->labelVideo->setStyleSheet("QLabel{border-image: url(Resources/image/background.png);}");
}

//���ô򿪰�ť��ʼ����
void GestureBasedUserIdentification::setButtonOpen(){
	buttonOpen = new QPushButton(this);
	buttonOpen->setText("Open");
	QFont font("Times", 18, 50);
	buttonOpen->setFont(font);
	buttonOpen->setGeometry(QRect(200, 700, 100, 50));
	buttonOpen->setStyleSheet("QPushButton{background-color:#009ad6; color:black}"
		"QPushButton:hover{background-color:#11264f; color: white;}"
		"QPushButton:pressed{background-color:#11264f;color: white }");
}

//���ùرհ�ť��ʼ����
void GestureBasedUserIdentification::setButtonStop(){
	buttonStop = new QPushButton(this);
	buttonStop->setText("Stop");
	QFont font("Times", 18, 50);
	buttonStop->setFont(font);
	buttonStop->setGeometry(QRect(760, 700, 100, 50));
	buttonStop->setStyleSheet("QPushButton{background-color:#009ad6; color:black}"
		"QPushButton:hover{background-color:#11264f; color: white;}"
		"QPushButton:pressed{background-color:#11264f;color: white }");
}

void GestureBasedUserIdentification::setLabelStatus(){
	labelStatus = new QLabel(this);
	labelStatus->setGeometry(QRect(1200, 200, 207, 207));
	if (gestureStatusForShow == 1){
		this->labelStatus->setStyleSheet("QLabel{border-image: url(Resources/image/wait.png);}");
	}
	else if (gestureStatusForShow == 2){
		this->labelStatus->setStyleSheet("QLabel{border-image: url(Resources/image/ready.png);}");
	}
	else if (gestureStatusForShow == 3){
		this->labelStatus->setStyleSheet("QLabel{border-image: url(Resources/image/doing.png);}");
	}
}


//�򿪰�ť�����¼�
void GestureBasedUserIdentification::startCapture(){
	if (isCameraOpened == false){
		buttonOpen->setStyleSheet("QPushButton{background-color:#11264f; color:white}"
			"QPushButton:hover{background-color:#11264f; color: white;}"
			"QPushButton:pressed{background-color:#11264f;color: white }");
		buttonStop->setStyleSheet("QPushButton{background-color:#009ad6; color:black}"
			"QPushButton:hover{background-color:#11264f; color: white;}"
			"QPushButton:pressed{background-color:#11264f;color: white }");
		init();
		isCameraOpened = true;
		pKinectSensor->Open();
	}
	else if (isCameraOpened == true){
		QMessageBox::information(this, QString::fromLocal8Bit("Warning"), QString::fromLocal8Bit("Kinect is already open!"));
	}
	
	if (isCameraOpened == true){
		timer = new QTimer(this);
		timer->setInterval(20);   //set timer match with FPS
		connect(timer, SIGNAL(timeout()), this, SLOT(nextFrame()));
		timer->start();
	}
}

void GestureBasedUserIdentification::nextFrame()
{
	if (isCameraOpened == true){
		bool isRefresh = pKinectSensor->SetData();
		frame = pKinectSensor->GetShowData();
		
		if (isRefresh == true){
			vector<point3d> bodyCoord = pKinectSensor->GetBodyData();//��ȡ�ؽ���Ϣ
			vector<point2d> body2dCoord = pKinectSensor->GetBody2DData();
			if (bodyCount <= 5){
				bodyDataSequence.push_back(bodyCoord);
			}
			else{
				bodyDataSequence.erase(bodyDataSequence.begin());
				bodyDataSequence.push_back(bodyCoord);
				vector<point3d > normBodyData = dataNormalization(bodyDataSequence);
				gestureStatus = mGestureStatus(ann, normBodyData, frame, body2dCoord);
				//������δ��ʼ����ʼ��������ʼλ
				if (isGestureReady == false && isGestureStart == false){
					if (gestureStatus == 0){
						readyFrameCount++;
					}
					else{
						readyFrameCount = 0;
					}
					if (readyFrameCount >= readyFrameNum){
						readyFrameCount = 0;
						isGestureReady = true;
						//cout << "�ȴ���������......" << endl;
						gestureStatusForShow = 2;
					}
				}
				if (isGestureStart == false && isGestureReady == true){
					if (gestureStatus != 0){
						startFramCount++;
					}
					else{
						startFramCount = 0;
					}
				}
				//�����ƿ�ʼ����ʼ����������λ
				if (isGestureStart == true){
					if (gestureStatus == 0){
						finishFrameCount++;
					}
					else{
						finishFrameCount = 0;
					}
				}
				//���ƿ�ʼ
				if (startFramCount >= startFrameNum && isGestureStart == false){
					startFramCount = 0;
					isGestureStart = true;
					//cout << "���ƿ�ʼ��" << endl;
					gestureStatusForShow = 3;
				}

				if (isGestureStart == true){
					gestureSequence.push_back(normBodyData);
					if (isIdentify == false){
						gestureSourceSequence.push_back(bodyCoord);
					}
				}
				//���ƽ���
				if (finishFrameCount >= finishFrameNum && isGestureFinished == false){
					finishFrameCount = 0;
					isGestureFinished = true;
					isGestureStart = false;
					isGestureReady = false;
					//cout << "���ƽ���" << endl;
					gestureStatusForShow = 1;
				}

				if (isGestureFinished == true){
					isGestureFinished = false;
				//ʶ��
					if (gestureSequence.size() < 20){
						QMessageBox::information(this, QString::fromLocal8Bit("Warning:Invalid gesture"), QString::fromLocal8Bit("The gesture sequence is too short!"));
					}
					else{
						gestureSequence.erase(gestureSequence.end() - 10, gestureSequence.end() - 1);
						pDTW->SetInputTrack(gestureSequence);
						UserID = pDTW->GetUserID();
						GestureID = pDTW->GetGestureID();
						string adminIdentity = comboBox->currentText().toStdString();
						string messageTitle;
						if (adminIdentity == UserName[UserID]){
							ofstream ofile("./Resources/gestureType.txt");
							ofile << std::string(GestureName[GestureID]);
							ofile.close();
							emit sedResultWindTxt();
							showResultWindow();
						}
						else{
							messageTitle = "No permission!";
							string recognitionResult = "Your Identity: " + UserName[UserID] + "\n Gesture Type: " + GestureName[GestureID];
							QMessageBox::information(this, QString::fromStdString(messageTitle), QString::fromStdString(recognitionResult));
							gestureSequence.clear();
						}
					}
				}
			}
			bodyCount++;

		}
		cv::resize(frame, frame, Size(960, 540));
		if (!frame.empty())
		{
			QImage frameImage = Mat2QImage(frame);
			this->labelVideo->setPixmap(QPixmap::fromImage(frameImage));
		}
		if (gestureStatusForShow == 1){
			this->labelStatus->setStyleSheet("QLabel{border-image: url(Resources/image/wait.png);}");
		}
		else if (gestureStatusForShow == 2){
			this->labelStatus->setStyleSheet("QLabel{border-image: url(Resources/image/ready.png);}");
		}
		else if (gestureStatusForShow == 3){
			this->labelStatus->setStyleSheet("QLabel{border-image: url(Resources/image/doing.png);}");
		}
	}
	else{
		pKinectSensor->Close();
		Mat backgroundImage = imread("./Resources/image/background.png");
		QImage background = Mat2QImage(backgroundImage);
		this->labelVideo->setPixmap(QPixmap::fromImage(background));
	}
	
}

void GestureBasedUserIdentification::stopCapture(){
	if (isCameraOpened == false){
		buttonStop->setStyleSheet("QPushButton{background-color:#11264f; color:white}"
			"QPushButton:hover{background-color:#11264f; color: white;}"
			"QPushButton:pressed{background-color:#11264f;color: white }");
		buttonOpen->setStyleSheet("QPushButton{background-color:#009ad6; color:black}"
			"QPushButton:hover{background-color:#11264f; color: white;}"
			"QPushButton:pressed{background-color:#11264f;color: white }");
		QMessageBox::information(this, QString::fromLocal8Bit("Warning"), QString::fromLocal8Bit("Kinect is not open!"));
	}
	else if (isCameraOpened == true){
		buttonStop->setStyleSheet("QPushButton{background-color:#11264f; color:white}"
			"QPushButton:hover{background-color:#11264f; color: white;}"
			"QPushButton:pressed{background-color:#11264f;color: white }");
		buttonOpen->setStyleSheet("QPushButton{background-color:#009ad6; color:black}"
			"QPushButton:hover{background-color:#11264f; color: white;}"
			"QPushButton:pressed{background-color:#11264f;color: white }");
		isCameraOpened = false;
	}
}


//����¼�
void GestureBasedUserIdentification::mousePressEvent(QMouseEvent *e)
{
	last = e->globalPos();
}
void GestureBasedUserIdentification::mouseMoveEvent(QMouseEvent *e)
{
	int dx = e->globalX() - last.x();
	int dy = e->globalY() - last.y();
	last = e->globalPos();
	move(x() + dx, y() + dy);
}
void GestureBasedUserIdentification::mouseReleaseEvent(QMouseEvent *e)
{
	int dx = e->globalX() - last.x();
	int dy = e->globalY() - last.y();
	move(x() + dx, y() + dy);
}

//Mat ת��Ϊ QImage
QImage  GestureBasedUserIdentification::Mat2QImage(cv::Mat cvImg)
{
	QImage qImg;
	if (cvImg.channels() == 3)                             //3 channels color image
	{
		cv::cvtColor(cvImg, cvImg, CV_BGR2RGB);
		qImg = QImage((const unsigned char*)(cvImg.data),
			cvImg.cols, cvImg.rows,
			cvImg.cols*cvImg.channels(),
			QImage::Format_RGB888);
	}
	else if (cvImg.channels() == 1)                    //grayscale image
	{
		qImg = QImage((const unsigned char*)(cvImg.data),
			cvImg.cols, cvImg.rows,
			cvImg.cols*cvImg.channels(),
			QImage::Format_Indexed8);
	}
	else
	{
		qImg = QImage((const unsigned char*)(cvImg.data),
			cvImg.cols, cvImg.rows,
			cvImg.cols*cvImg.channels(),
			QImage::Format_RGB888);
	}
	return qImg;
}

//�ؽ����Ļ�
vector<point3d > GestureBasedUserIdentification::dataNormalization(vector<vector<point3d>>  bodyDataSequence){
	vector<point3d > bodyData = GaussianSmooth(bodyDataSequence);
	vector<point3d > normBodyData;

	//dΪneck-spinebase����
	float d = sqrt((bodyData[20].x - bodyData[1].x)*(bodyData[20].x - bodyData[1].x) + (bodyData[20].y - bodyData[1].y)*(bodyData[20].y - bodyData[1].y) + (bodyData[20].z - bodyData[1].z)*(bodyData[20].z - bodyData[1].z));
	for (int type = 0; type < JointType::JointType_Count; ++type){
		point3d normBodyDataBuf;
		normBodyDataBuf.x = (bodyData[type].x - bodyData[1].x) / d;
		normBodyDataBuf.y = (bodyData[type].y - bodyData[1].y) / d;
		normBodyDataBuf.z = (bodyData[type].z - bodyData[1].z) / d;
		normBodyData.push_back(normBodyDataBuf);
	}
	return normBodyData;
}

//��˹ƽ��
vector<point3d> GestureBasedUserIdentification::GaussianSmooth(vector<vector<point3d>> bodyDataSequence){
	float x[5];
	float f[5];
	vector<point3d> smoothData;
	for (int type = 0; type < JointType::JointType_Count; ++type){
		float Px[5] = { bodyDataSequence[0][type].x, bodyDataSequence[1][type].x, bodyDataSequence[2][type].x, bodyDataSequence[3][type].x, bodyDataSequence[4][type].x };
		float Py[5] = { bodyDataSequence[0][type].y, bodyDataSequence[1][type].y, bodyDataSequence[2][type].y, bodyDataSequence[3][type].y, bodyDataSequence[4][type].y };
		float Pz[5] = { bodyDataSequence[0][type].z, bodyDataSequence[1][type].z, bodyDataSequence[2][type].z, bodyDataSequence[3][type].z, bodyDataSequence[4][type].z };
		float d1 = sqrt((Px[0] - Px[1])*(Px[0] - Px[1]) + (Py[0] - Py[1])*(Py[0] - Py[1]) + (Pz[0] - Pz[1])*(Pz[0] - Pz[1]));
		float d2 = sqrt((Px[1] - Px[2])*(Px[1] - Px[2]) + (Py[1] - Py[2])*(Py[1] - Py[2]) + (Pz[1] - Pz[2])*(Pz[1] - Pz[2]));
		float d3 = sqrt((Px[2] - Px[3])*(Px[2] - Px[3]) + (Py[2] - Py[3])*(Py[2] - Py[3]) + (Pz[2] - Pz[3])*(Pz[2] - Pz[3]));
		float d4 = sqrt((Px[3] - Px[4])*(Px[3] - Px[4]) + (Py[3] - Py[4])*(Py[3] - Py[4]) + (Pz[3] - Pz[4])*(Pz[3] - Pz[4]));
		float u = (d1 + d2 + d3 + d4) / 4;
		float s = (d1 + d2)>(d3 + d4) ? (d1 + d2) : (d3 + d4);
		for (int row = 0; row < 5; row++){
			x[row] = sqrt((Px[2] - Px[row])*(Px[2] - Px[row]) + (Py[2] - Py[row])*(Py[2] - Py[row]) + (Pz[2] - Pz[row])*(Pz[2] - Pz[row]));
		}
		for (int row = 0; row < 5; row++){
			f[row] = (exp(-(x[row] - u)*(x[row] - u) / (2 * s*s))) / sqrt(2 * 3.1415*s);
		}
		point3d smoothJoint;
		smoothJoint.x = (f[0] * Px[0] + f[1] * Px[1] + f[2] * Px[2] + f[3] * Px[3] + f[4] * Px[4]) / f[4];
		smoothJoint.y = (f[0] * Py[0] + f[1] * Py[1] + f[2] * Py[2] + f[3] * Py[3] + f[4] * Py[4]) / f[4];
		smoothJoint.z = (f[0] * Pz[0] + f[1] * Pz[1] + f[2] * Pz[2] + f[3] * Pz[3] + f[4] * Pz[4]) / f[4];
		smoothData.push_back(smoothJoint);
	}
	return smoothData;
}

/*���ùؽ���Ϣ�ж�����״̬������ʹ�õ��Ǵ����Ĺؽ����ݣ�*/
int GestureBasedUserIdentification::mGestureStatus(struct fann *ann, vector<point3d> bodydata, Mat &frame, vector<point2d> body2dCoord){
	int status = -1;//0=��ֹ��1=���֣�2=���֣�3=˫��
	double dataBuf[18];
	int count = 0;
	for (int type = 0; type < JointType::JointType_Count; type++){
		if (type == 7 || type == 11 || type == 21 || type == 22 || type == 23 || type == 24){
			dataBuf[count * 3] = bodydata[type].x;
			dataBuf[count * 3 + 1] = bodydata[type].y;
			dataBuf[count * 3 + 2] = bodydata[type].z;
			count++;
		}
	}

	double *output = fann_run(ann, dataBuf);

	//����
	if (output[1] >0.5){
		cv::circle(frame, cv::Point(body2dCoord[7].x, body2dCoord[7].y), 75, cv::Scalar(0, 0, 255), 5, CV_AA);//�˶���ʾ��ɫȦ��BGR��
	}
	else{
		cv::circle(frame, cv::Point(body2dCoord[7].x, body2dCoord[7].y), 75, cv::Scalar(255, 0, 0), 5, CV_AA);//��ֹ��ʾ��ɫȦ
	}
	//����
	if (output[0] > 0.5){
		cv::circle(frame, cv::Point(body2dCoord[11].x, body2dCoord[11].y), 75, cv::Scalar(0, 0, 255), 5, CV_AA);//��Ȧ
	}
	else{
		cv::circle(frame, cv::Point(body2dCoord[11].x, body2dCoord[11].y), 75, cv::Scalar(255, 0, 0), 5, CV_AA);//��Ȧ
	}

	if (output[0] > 0.5 && output[1] > 0.5){
		status = 3;
	}
	else if (output[0] <= 0.5 && output[1] > 0.5){
		status = 2;
	}
	else if (output[0] > 0.5 && output[1] <= 0.5){
		status = 1;
	}
	else{
		status = 0;
	}

	return status;
}

void GestureBasedUserIdentification::showResultWindow(){
	w2.show();
	QTimer::singleShot(3000, this, SLOT(closeResultWindow()));
}

void GestureBasedUserIdentification::closeResultWindow(){
	w2.close();
}
