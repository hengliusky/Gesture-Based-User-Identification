#include "resultshow.h"
#include <fstream> 
using namespace std;
ResultShow::ResultShow(QWidget *parent)
	: QWidget(parent)
{
	ui.setupUi(this);
	setWindowStyle();
	setLabelTitle();
	setButtonClose();
	setLabelMessage();
	setLabelBottom();
	connect(buttonClose, SIGNAL(clicked()), this, SLOT(close()));
}

ResultShow::~ResultShow()
{

}

void ResultShow::setLabelBottom(){
	labelBottom = new QLabel(this);
	labelBottom->setGeometry(QRect(0, 475, 640, 2));
	labelBottom->setStyleSheet("background:#008792;");


	labelLeft = new QLabel(this);
	labelLeft->setGeometry(QRect(0, 50, 2, 430));
	labelLeft->setStyleSheet("background:#008792;");

	labelRight = new QLabel(this);
	labelRight->setGeometry(QRect(638, 50, 2, 430));
	labelRight->setStyleSheet("background:#008792;");
}

void ResultShow::setWindowStyle(){
	this->setWindowFlags(Qt::FramelessWindowHint);
	this->setWindowIcon(QIcon("./Resources/image/title.jpg"));
	this->setMaximumSize(640, 480);
	this->setMinimumSize(640, 480);
	this->setStyleSheet("background:#cde6c7;");
}

void ResultShow::setLabelTitle(){
	labelTitle = new QLabel(this);
	labelTitle->setGeometry(QRect(0, 0, 640, 50));
	QFont    font("Times", 16, 75);    //��һ�����������壨΢���źڣ����ڶ����Ǵ�С���������ǼӴ֣�Ȩ����75��
	labelTitle->setFont(font);
	labelTitle->setStyleSheet("background:#008792;");
}
void ResultShow::refreshLableTitle(){
	ifstream ifile("./Resources/gestureType.txt");
	string gestureNameBuf;
	if (ifile) // �и��ļ�  
	{
		getline(ifile, gestureNameBuf); // line�в�����ÿ�еĻ��з�  

	}
	labelTitle->setText(QString::fromStdString(gestureNameBuf));
}
void ResultShow::setLabelMessage(){
	labelMessage = new QLabel(this);
	labelMessage->setGeometry(QRect(83, 100, 563, 207));
	labelMessage->setStyleSheet("QLabel{border-image: url(Resources/image/welcome.png);}");
}

void ResultShow::setButtonClose(){
	buttonClose = new QPushButton(this);
	buttonClose->setText("OK");
	QFont    font("Times", 16, 50);
	buttonClose->setFont(font);
	buttonClose->setGeometry(QRect(270, 380,100, 40));

	buttonClose->setStyleSheet("QPushButton{background-color:#009ad6; color:black}"
		"QPushButton:hover{background-color:#11264f; color: white;}"
		"QPushButton:pressed{background-color:#11264f;color: white }");
}

//����¼�
void ResultShow::mousePressEvent(QMouseEvent *e)
{
	last = e->globalPos();
}
void ResultShow::mouseMoveEvent(QMouseEvent *e)
{
	int dx = e->globalX() - last.x();
	int dy = e->globalY() - last.y();
	last = e->globalPos();
	move(x() + dx, y() + dy);
}
void ResultShow::mouseReleaseEvent(QMouseEvent *e)
{
	int dx = e->globalX() - last.x();
	int dy = e->globalY() - last.y();
	move(x() + dx, y() + dy);
}
