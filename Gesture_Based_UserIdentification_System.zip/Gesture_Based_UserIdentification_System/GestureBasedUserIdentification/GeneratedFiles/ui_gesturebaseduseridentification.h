/********************************************************************************
** Form generated from reading UI file 'gesturebaseduseridentification.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GESTUREBASEDUSERIDENTIFICATION_H
#define UI_GESTUREBASEDUSERIDENTIFICATION_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_GestureBasedUserIdentificationClass
{
public:
    QWidget *centralWidget;

    void setupUi(QMainWindow *GestureBasedUserIdentificationClass)
    {
        if (GestureBasedUserIdentificationClass->objectName().isEmpty())
            GestureBasedUserIdentificationClass->setObjectName(QStringLiteral("GestureBasedUserIdentificationClass"));
        GestureBasedUserIdentificationClass->resize(600, 400);
        centralWidget = new QWidget(GestureBasedUserIdentificationClass);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        GestureBasedUserIdentificationClass->setCentralWidget(centralWidget);

        retranslateUi(GestureBasedUserIdentificationClass);

        QMetaObject::connectSlotsByName(GestureBasedUserIdentificationClass);
    } // setupUi

    void retranslateUi(QMainWindow *GestureBasedUserIdentificationClass)
    {
        GestureBasedUserIdentificationClass->setWindowTitle(QApplication::translate("GestureBasedUserIdentificationClass", "GestureBasedUserIdentification", 0));
    } // retranslateUi

};

namespace Ui {
    class GestureBasedUserIdentificationClass: public Ui_GestureBasedUserIdentificationClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GESTUREBASEDUSERIDENTIFICATION_H
