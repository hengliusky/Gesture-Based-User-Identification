#include "global.h"
#include "CKinectSensor.h"
#define max(a,b) a>b?a:b
using namespace std;
using namespace cv;
CKinectSensor::CKinectSensor()
{
	m_hResult = true;
	m_nColorWidth = 0;
	m_nColorHeight = 0;
	m_nDepthMinReliableDistance=0;//��ȡ�����С��Ⱦ�����Ϣ
	m_nDepthMaxReliableDistance=0;
	m_nMapDepthToByte = 4096 / 256;
}

CKinectSensor::~CKinectSensor()
{

}
byte CKinectSensor::CalculateIntensityFromDepth(int distance,int minDistance,int maxDistance){
	
	return (byte)(distance >= minDistance && distance <= maxDistance ? (distance / m_nMapDepthToByte) : 0);
}
/*******************************��Kinect�豸*******************************/
bool CKinectSensor::__GetDefaultSensor(){
	HRESULT hResult = S_OK;//����ֵ

	//���Ĭ�ϵ�Kinect������
	hResult = GetDefaultKinectSensor(&m_pSensor);
	if (FAILED(hResult)){
		return false;
	}

	//��Kinect���������쳣����
	hResult = m_pSensor->Open();
	if (FAILED(hResult)){
		return false;
	}
	return true;
}

bool CKinectSensor::__GetFrameSource(){
	HRESULT hResult = S_OK;//����ֵ

	//��ɫ����Դ���쳣����
	hResult = m_pSensor->get_ColorFrameSource(&m_pColorSource);
	if (FAILED(hResult)){
		return false;
	}

	//�ؽ�����Դ���쳣����
	hResult = m_pSensor->get_BodyFrameSource(&m_pBodySource);
	if (FAILED(hResult)){
		return false;
	}

	//hResult = m_pSensor->get_DepthFrameSource(&m_pDepthSource);
	//if (FAILED(hResult)){
	//	return false;
	//}

	//hResult = m_pSensor->get_BodyIndexFrameSource(&m_pBodyIndexSource);
	//if (FAILED(hResult)){
	//	return false;
	//}

	return true;
}

bool CKinectSensor::__GetFrameReader(){
	HRESULT hResult = S_OK;//����ֵ

	//��ɫ���ݶ�ȡ��
	hResult = m_pColorSource->OpenReader(&m_pColorReader);
	if (FAILED(hResult)){
		return false;
	}

	//�ؽ����ݶ�ȡ��
	hResult = m_pBodySource->OpenReader(&m_pBodyReader);
	if (FAILED(hResult)){
		return false;
	}
	//������ݶ�ȡ��
	//hResult = m_pDepthSource->OpenReader(&m_pDepthReader);
	//if (FAILED(hResult)){
	//	return false;
	//}

	//hResult = m_pBodyIndexSource->OpenReader(&m_pBodyIndexReader);
	//if (FAILED(hResult)){
	//	return false;
	//}

	return true;
}

bool CKinectSensor::__GetFrameDescriotion(){
	HRESULT hResult = S_OK;//����ֵ
	
	hResult = m_pColorSource->get_FrameDescription(&m_pColorDescription);
	if (FAILED(hResult)){
		return false;
	}

	//hResult = m_pDepthSource->get_FrameDescription(&m_pDepthDescription);
	//if (FAILED(hResult)){
	//	return false;
	//}

	//hResult = m_pBodyIndexSource->get_FrameDescription(&m_pBodyDescription);
	//if (FAILED(hResult)){
	//	return false;
	//}

	return true;
}

bool CKinectSensor::__GetCoordinateMapper(){
	HRESULT hResult = S_OK;//����ֵ
	hResult = m_pSensor->get_CoordinateMapper(&m_pCoordinateMapper);
	if (FAILED(hResult)){
		return false;
	}
	return true;
}

void CKinectSensor::__SetImageFormat(){
	//���ͼ��ĸ�ʽ��С
	m_pColorDescription->get_Width(&m_nColorWidth); // 1920
	m_pColorDescription->get_Height(&m_nColorHeight); // 1080
	m_nImageDataSize = m_nColorWidth * m_nColorHeight * 4 * sizeof(unsigned char);
	m_mSourceImage.create(m_nColorHeight, m_nColorWidth, CV_8UC4);
	m_mShowImage.create(m_nColorHeight, m_nColorWidth, CV_8UC3);
	m_mImageBuf.create(IMAGE_HEIGHT, IMAGE_WIDTH, CV_8UC3);

	//m_pDepthDescription->get_Width(&m_nDepthWidth);//512
	//m_pDepthDescription->get_Height(&m_nDepthHeight); // 424
	//m_nDepthDataSize = m_nDepthWidth*m_nDepthHeight;
	//m_mDepthImage.create(m_nDepthHeight, m_nDepthWidth, CV_8UC1);
	//m_mDepthBuf.create(IMAGE_HEIGHT, IMAGE_WIDTH, CV_8UC3);

	//m_pBodyDescription->get_Width(&m_nBodyWidth);
	//m_pBodyDescription->get_Height(&m_nBodyHeight);
	//m_nBodyDataSize = m_nBodyWidth*m_nBodyHeight;
	
}


/*******************************��ȡ����*************************************/
bool CKinectSensor::__IsDeviceOpened(){
	if (__GetDefaultSensor()==false){
		m_hResult = false;
		m_nErrorMes = 1;
		return m_hResult;
	}
	if (__GetFrameSource() == false){
		m_hResult = false;
		m_nErrorMes = 2;
		return m_hResult;
	}
	if (__GetFrameReader() == false){
		m_hResult = false;
		m_nErrorMes = 3;
		return m_hResult;
	}
	if (__GetFrameDescriotion() == false){
		m_hResult = false;
		m_nErrorMes = 4;
		return m_hResult;
	}
	if (__GetCoordinateMapper() == false){
		m_hResult = false;
		m_nErrorMes = 5;
		return m_hResult;
	}
	return true;
}

bool CKinectSensor::__GetImageSource(){
	HRESULT hResult = S_OK;//����ֵ
	bool isOK = false;
	// Frame���²�ɫ֡ 

	IColorFrame* pColorFrame = nullptr;//��ɫ֡
	hResult = m_pColorReader->AcquireLatestFrame(&pColorFrame);//AcquireLatestFrame()������µĲ�ɫ֡��Ϣ
	if (SUCCEEDED(hResult)){
		//�����ò�ɫ���ݳɹ�����ôת��֡���ݸ��Ƶ�������
		hResult = pColorFrame->CopyConvertedFrameDataToArray(m_nImageDataSize, reinterpret_cast<BYTE*>(m_mSourceImage.data), ColorImageFormat::ColorImageFormat_Bgra);
		cvtColor(m_mSourceImage, m_mImageBuf, CV_RGBA2RGB);
		m_mShowImage = m_mImageBuf;
		resize(m_mImageBuf, m_mImageBuf, Size(IMAGE_WIDTH, IMAGE_HEIGHT));
		//m_mShowImage = m_mSourceImage;
		isOK = true;
	}
	SafeRelease(pColorFrame);
	return isOK;
}

//bool CKinectSensor::__GetDepthSource(){
//	HRESULT hResult = S_OK;//����ֵ
//	bool isOK = false;
//	IDepthFrame* pDepthFrame = NULL;
//	hResult = m_pDepthReader->AcquireLatestFrame(&pDepthFrame);
//	if (SUCCEEDED(hResult)){
//		hResult = pDepthFrame->get_DepthMaxReliableDistance(&m_nDepthMaxReliableDistance);
//		hResult = pDepthFrame->get_DepthMinReliableDistance(&m_nDepthMinReliableDistance);
//		UINT16 *depthArray = new UINT16[m_nDepthDataSize];//���������16λunsigned int
//		hResult = pDepthFrame->CopyFrameDataToArray(m_nDepthDataSize, depthArray);
//		//��������ݻ���MAT��
//		byte* depthData = (byte*)m_mDepthImage.data;
//		for (int i = 0; i < m_nDepthDataSize; ++i){
//			byte distance = CalculateIntensityFromDepth(depthArray[i], m_nDepthMinReliableDistance, m_nDepthMaxReliableDistance);
//			*depthData = distance;
//			++depthData;
//		}
//		//equalizeHist(m_mDepthImage, m_mDepthImage);
//		//isOK = __GetBodyImageSource(depthArray);
//		delete[] depthArray;
//		isOK = true;
//	}
//	SafeRelease(pDepthFrame);
//	return isOK;
//}

//bool CKinectSensor::__GetBodyImageSource(UINT16 *depthArray){
//	bool isOK = false;
//	HRESULT hResult = S_OK;
//	BYTE * bodyData = new BYTE[m_nBodyDataSize];	
//	int colorImageSizeBuf = m_nColorWidth * m_nColorHeight;
//	DepthSpacePoint * output = new DepthSpacePoint[colorImageSizeBuf];
//	IBodyIndexFrame * myBodyIndexFrame = nullptr;
//	m_mBodyImage = Mat::zeros(m_nColorHeight, m_nColorWidth, CV_8UC1);
//	hResult = m_pBodyIndexReader->AcquireLatestFrame(&myBodyIndexFrame);
//	
//	if (SUCCEEDED(hResult)){
//		myBodyIndexFrame->CopyFrameDataToArray(m_nBodyDataSize, bodyData);
//		if (m_pCoordinateMapper->MapColorFrameToDepthSpace(m_nDepthDataSize, depthArray, m_nColorWidth * m_nColorHeight, output) == S_OK)
//		{
//			uchar* dataBuf = m_mBodyImage.ptr < uchar >(0);
//			for (int i = 0; i < colorImageSizeBuf; ++i){
//					DepthSpacePoint tPoint = output[i];    //ȡ�ò�ɫͼ���ϵ�һ�㣬�˵����������Ӧ�����ͼ�ϵ�����
//					if (tPoint.X >= 0 && tPoint.X < m_nDepthWidth && tPoint.Y >= 0 && tPoint.Y <m_nDepthHeight){
//						int index = (int)tPoint.Y * m_nDepthWidth + (int)tPoint.X; //ȡ�ò�ɫͼ���ǵ��Ӧ��BodyIndex���ֵ(ע��Ҫǿת)
//						if (bodyData[index] <= 5){
//							//m_mBodyImage.at<uchar>(i, j) =255;
//							*dataBuf = 255;
//						}
//					}
//				dataBuf++;
//			}
//			resize(m_mBodyImage, m_mBodyImage, Size(IMAGE_WIDTH, IMAGE_HEIGHT));
//			//imshow("m_mBodyImage", m_mBodyImage);
//			isOK = true;
//		}
//	}
//	delete[] bodyData;
//	delete[] output;
//	SafeRelease(myBodyIndexFrame);
//	return isOK;
//}

bool CKinectSensor::__GetBodyCoordSource(){
	bool isOK = false;
	m_nUserID = -1;
	HRESULT hResult = S_OK;//����ֵ
	m_joint3dCoord.clear();
	m_joint2dCoord.clear();

	IBodyFrame* pBodyFrame = nullptr;
	hResult = m_pBodyReader->AcquireLatestFrame(&pBodyFrame);//������µ�body֡��Ϣ

	if (SUCCEEDED(hResult)){
		IBody* pBody[BODY_COUNT] = { 0 };
		hResult = pBodyFrame->GetAndRefreshBodyData(BODY_COUNT, pBody);//��ȡ��ˢ����������
		
		if (SUCCEEDED(hResult)){
			#pragma omp parallel for
			for (int UserID = 0; UserID < BODY_COUNT; UserID++)//
			{
				BOOLEAN bTracked = false;//Ĭ����δ����״̬
				hResult = pBody[UserID]->get_IsTracked(&bTracked);//ȷ��Ŀ���Ƿ񱻸��٣�������״̬true/false
				if (SUCCEEDED(hResult) && bTracked)
				{	
					Joint joint[JointType::JointType_Count];//����һ��joint���飬����JointType::JointType_Count��ʾ�ؽڸ���
					hResult = pBody[UserID]->GetJoints(JointType::JointType_Count, joint);//��ùؽ���Ϣ������״ֵ̬

					if (SUCCEEDED(hResult))
					{
						CvPoint skeletonPoint[BODY_COUNT][JointType_Count] = { cvPoint(0, 0) };

						vector<point3d> joint3Dsource;
						vector<point2d> joint2Dsource;
						for (int type = 0; type < JointType::JointType_Count; type++)//�ؽڸ���
						{
							point3d joint3DBuf;
							joint3DBuf.x = joint[type].Position.X;
							joint3DBuf.y = joint[type].Position.Y;
							joint3DBuf.z = joint[type].Position.Z;
							joint3Dsource.push_back(joint3DBuf);

							ColorSpacePoint colorSpacePoint = { 0 };
							m_pCoordinateMapper->MapCameraPointToColorSpace(joint[type].Position, &colorSpacePoint);//ÿ���ؽڵ�ӳ�䵽��ɫ�ռ��	
							point2d joint2Dbuf;
							skeletonPoint[UserID][type].x = static_cast<int>(colorSpacePoint.X);//�ѹؽ�x�����긳ֵ������õ�����
							skeletonPoint[UserID][type].y = static_cast<int>(colorSpacePoint.Y);
							joint2Dbuf.x = static_cast<int>(colorSpacePoint.X);
							joint2Dbuf.y = static_cast<int>(colorSpacePoint.Y);
							joint2Dsource.push_back(joint2Dbuf);
						}
						m_joint3dCoord = joint3Dsource;
						m_joint2dCoord = joint2Dsource;
						m_nUserID = UserID;
						__DrawSkeleton(m_mShowImage, skeletonPoint[UserID], joint, UserID);//�����ؽ�����	
						isOK = true;
					}
				}
			}
		}
		
	}
	SafeRelease(pBodyFrame);
	return isOK;
}

//���������ؽڵ㣬��Ϊһ����
void CKinectSensor::__DrawBone(cv::Mat& SkeletonImage, CvPoint pointSet[], const Joint* pJoints, int whichone, JointType joint0, JointType joint1)//����������DrawBone���ؽ�ͼƬ����������ID���ؽ�1���ؽ�2��
{
	TrackingState joint0State = pJoints[joint0].TrackingState;//TrackingState����״̬
	TrackingState joint1State = pJoints[joint1].TrackingState;

	// ����Ҳ����������ؽ�,�˳�
	if ((joint0State == TrackingState_NotTracked) || (joint1State == TrackingState_NotTracked))
	{
		return;
	}
	// Don't draw if both points are inferred
	if ((joint0State == TrackingState_Inferred) && (joint1State == TrackingState_Inferred))
	{
		return;
	}

	CvScalar color;
	switch (whichone) //���ٲ�ͬ������ʾ��ͬ����ɫ   
	{
	case 0:
		color = cvScalar(255);
		break;
	case 1:
		color = cvScalar(0, 255);
		break;
	case 2:
		color = cvScalar(0, 0, 255);
		break;
	case 3:
		color = cvScalar(255, 255, 0);
		break;
	case 4:
		color = cvScalar(255, 0, 255);
		break;
	case 5:
		color = cvScalar(0, 255, 255);
		break;
	}

	// We assume all drawn bones are inferred unless BOTH joints are tracked
	if ((joint0State == TrackingState_Tracked) && (joint1State == TrackingState_Tracked))
	{
		line(SkeletonImage, pointSet[joint0], pointSet[joint1], color, 2);
	}
	else
	{
		line(SkeletonImage, pointSet[joint0], pointSet[joint1], color, 2);
	}
}

void CKinectSensor::__DrawSkeleton(Mat& SkeletonImage, CvPoint pointSet[], const Joint* pJoints, int whichone)
{
	// Torso
	__DrawBone(SkeletonImage, pointSet, pJoints, whichone, JointType_Head, JointType_Neck);
	__DrawBone(SkeletonImage, pointSet, pJoints, whichone, JointType_Neck, JointType_SpineShoulder);
	__DrawBone(SkeletonImage, pointSet, pJoints, whichone, JointType_SpineShoulder, JointType_SpineMid);
	__DrawBone(SkeletonImage, pointSet, pJoints, whichone, JointType_SpineMid, JointType_SpineBase);
	__DrawBone(SkeletonImage, pointSet, pJoints, whichone, JointType_SpineShoulder, JointType_ShoulderRight);
	__DrawBone(SkeletonImage, pointSet, pJoints, whichone, JointType_SpineShoulder, JointType_ShoulderLeft);
	__DrawBone(SkeletonImage, pointSet, pJoints, whichone, JointType_SpineBase, JointType_HipRight);
	__DrawBone(SkeletonImage, pointSet, pJoints, whichone, JointType_SpineBase, JointType_HipLeft);

	// Right Arm    
	__DrawBone(SkeletonImage, pointSet, pJoints, whichone, JointType_ShoulderRight, JointType_ElbowRight);
	__DrawBone(SkeletonImage, pointSet, pJoints, whichone, JointType_ElbowRight, JointType_WristRight);
	__DrawBone(SkeletonImage, pointSet, pJoints, whichone, JointType_WristRight, JointType_HandRight);
	__DrawBone(SkeletonImage, pointSet, pJoints, whichone, JointType_HandRight, JointType_HandTipRight);
	__DrawBone(SkeletonImage, pointSet, pJoints, whichone, JointType_WristRight, JointType_ThumbRight);

	// Left Arm
	__DrawBone(SkeletonImage, pointSet, pJoints, whichone, JointType_ShoulderLeft, JointType_ElbowLeft);
	__DrawBone(SkeletonImage, pointSet, pJoints, whichone, JointType_ElbowLeft, JointType_WristLeft);
	__DrawBone(SkeletonImage, pointSet, pJoints, whichone, JointType_WristLeft, JointType_HandLeft);
	__DrawBone(SkeletonImage, pointSet, pJoints, whichone, JointType_HandLeft, JointType_HandTipLeft);
	__DrawBone(SkeletonImage, pointSet, pJoints, whichone, JointType_WristLeft, JointType_ThumbLeft);

	// Right Leg
	__DrawBone(SkeletonImage, pointSet, pJoints, whichone, JointType_HipRight, JointType_KneeRight);
	__DrawBone(SkeletonImage, pointSet, pJoints, whichone, JointType_KneeRight, JointType_AnkleRight);
	__DrawBone(SkeletonImage, pointSet, pJoints, whichone, JointType_AnkleRight, JointType_FootRight);

	// Left Leg
	__DrawBone(SkeletonImage, pointSet, pJoints, whichone, JointType_HipLeft, JointType_KneeLeft);
	__DrawBone(SkeletonImage, pointSet, pJoints, whichone, JointType_KneeLeft, JointType_AnkleLeft);
	__DrawBone(SkeletonImage, pointSet, pJoints, whichone, JointType_AnkleLeft, JointType_FootLeft);
}

/********************************�ⲿ�ӿ�************************************/
bool CKinectSensor::Open(){
	__IsDeviceOpened();
	__SetImageFormat();
	return m_hResult;
}

void CKinectSensor::Close(){
	if (m_pSensor)
	{
		m_pSensor->Close();//�ر�Kinect
	}
}

bool CKinectSensor::SetData(){
	bool getColorSource,getBodySource;
	getColorSource = __GetImageSource();
	/*getDepthSource = __GetDepthSource();*/
	getBodySource = __GetBodyCoordSource();
	return (getColorSource&&getBodySource);
}

Mat CKinectSensor::GetImageData(){
	return m_mImageBuf;
}

vector<point3d> CKinectSensor::GetBodyData(){
	return m_joint3dCoord;
}

vector<point2d> CKinectSensor::GetBody2DData(){
	return m_joint2dCoord;
}

Mat CKinectSensor::GetShowData(){
	return m_mShowImage;
}

//Mat CKinectSensor::GetDepthData(){
//	return m_mDepthImage;
//}
//
//Mat CKinectSensor::GetBodyImage(){	
//	return m_mBodyImage;
//}