#include "gesturebaseduseridentification.h"
#include <QtWidgets/QApplication>
#include "GetQSS.h"
int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	GestureBasedUserIdentification w;

	GetQSS::setStyle("./Resources/combox.qss");
	w.show();
	return a.exec();
}
