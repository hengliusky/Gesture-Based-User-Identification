#include "DTW.h"
#include <fstream>

#define MIN(a,b) (a<b)?a:b

using namespace std;

DTW::DTW()

{
	//m_nTemplateNum = TEMPLATENUM;
	//m_nGestureNum = GESTURENUM;
	//m_nUserNum = USERNUM;
	m_templatePath = "./gestrueTemplate/";
	m_inputTrack.clear();
	int m_gestureID = -1;
	
}

DTW::~DTW()
{
}
void DTW::SetTemplateNum(int userNum, int gestureNum, int templateNum){
	m_nUserNum = userNum;
	m_nGestureNum = gestureNum;
	m_nTemplateNum = templateNum;
	__SetTemplateTrack();
}


/*�����ʶ������ƹ켣*/
void DTW::SetInputTrack(std::vector<std::vector<point3d>> inputTrack){
	__Init();
	for (int i = 0; i < inputTrack.size(); i++){
		vector<point3d> trackBuf;
		for (int type = 0; type < JointType::JointType_Count; ++type){
			if (type == 7 || type == 11 || type == 21 || type == 22 || type == 23 || type == 24){
				trackBuf.push_back(inputTrack[i][type]);
			}
		}
		m_inputTrack.push_back(trackBuf);
	}
	__DTWAlgorithm();
}

/*���ʶ����*/
int DTW::GetGestureID(){
	return m_nGestureID;
}

/*����û�ID*/
int DTW::GetUserID(){
	return m_nUserID;
}

/*��ȡ����ģ��*/
void DTW::__SetTemplateTrack(){
	for (int i = 0; i < m_nUserNum; ++i){
		string userPath = m_templatePath + to_string(i) + "/";
		for (int j = 0; j < m_nGestureNum; ++j){
			string gesturePath = userPath + to_string(j) + "/";
			for(int k = 0; k < m_nTemplateNum; ++k){
				string filePath = gesturePath + to_string(k) + ".txt";
				ifstream templateFile(filePath);
				vector<vector<point3d>> templateBuf;//��������
				while (templateFile.peek() != EOF){
					vector<point3d> templateFrameBuf;//��֡
					for (int type = 0; type < 6; ++type){
						point3d templateJointBuf;//�����ؽڵ�
						templateFile >> templateJointBuf.x >> templateJointBuf.y >> templateJointBuf.z;
						templateFrameBuf.push_back(templateJointBuf);
					}
					templateBuf.push_back(templateFrameBuf);
				}
				if (templateBuf.size() > 1){//ȥ��β���ظ�
					templateBuf.erase(templateBuf.end() - 1);
				}	
				m_templateTrack.push_back(templateBuf);
			}
		}
	}
}

/*DTW�㷨*/
void DTW::__DTWAlgorithm(){
	float mindistince = 99999999.0;
	m_nGestureID = -1;
	m_nUserID = -1;
	//m_inputTrack = m_templateTrack[0];
	int inputTrackLength = m_inputTrack.size();

	for (int i = 0; i < m_nUserNum; ++i){
		for (int j = 0; j < m_nGestureNum; ++j){
			for (int k = 0; k < m_nTemplateNum; ++k){
				int	templateCount = i*m_nGestureNum*m_nTemplateNum + j*m_nTemplateNum + k;
				int templateTrackLength = m_templateTrack[templateCount].size();
				vector<vector <float>> distance(inputTrackLength + 1, vector<float>(templateTrackLength + 1, 0));
				vector<vector <float>> g(inputTrackLength + 1, vector<float>(templateTrackLength + 1, 0));
				vector<vector <float>> output(inputTrackLength + 1, vector<float>(templateTrackLength + 1, 0));

				for (int p = 0; p < inputTrackLength; ++p){
					for (int q = 0; q < templateTrackLength; ++q){
						for (int type = 0; type < 6; ++type){
								distance[p][q] += sqrt((m_inputTrack[p][type].x - m_templateTrack[templateCount][q][type].x)*(m_inputTrack[p][type].x - m_templateTrack[templateCount][q][type].x) +
									(m_inputTrack[p][type].y - m_templateTrack[templateCount][q][type].y)*(m_inputTrack[p][type].y - m_templateTrack[templateCount][q][type].y) +
									(m_inputTrack[p][type].z - m_templateTrack[templateCount][q][type].z)*(m_inputTrack[p][type].z - m_templateTrack[templateCount][q][type].z));
						}
					}
				}
				g[0][0] = 2 * distance[0][0];
				for (int p = 1; p < inputTrackLength; p++){
					g[p][0] = g[p - 1][0] + distance[p][0];
				}
				for (int q = 1; q < templateTrackLength; q++){
					g[0][q] = g[0][q - 1] + distance[0][q];
				}
				for (int p = 1; p <= inputTrackLength; p++){
					for (int q = 1; q <= templateTrackLength; q++){
						float t = MIN((g[p][q - 1] + distance[p][q]), (g[p - 1][q - 1] + 2 * distance[p][q]));
						g[p][q] = MIN(t, (g[p - 1][q] + distance[p][q]));     //���ϣ����3��������Сֵ��MIN��MIN������������;�����ʽ���á��ɷֿ�д��

					}
				}
				float sumDistanceBuf = (g[inputTrackLength - 1][templateTrackLength - 1] / (inputTrackLength + templateTrackLength));
				//cout << sumDistanceBuf << "\t";
				if (sumDistanceBuf < mindistince){
					mindistince = sumDistanceBuf;
					m_nUserID = i;
					m_nGestureID = j;
				}
			}
		}
	}
	//cout << endl;
}

void DTW::__Init(){
	m_inputTrack.clear();
	int m_gestureID = -1;
}