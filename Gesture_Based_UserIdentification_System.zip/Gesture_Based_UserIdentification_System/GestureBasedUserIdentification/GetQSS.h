#include <qfile.h>
#include <qapplication.h>

class GetQSS
{
public:
	static void setStyle(const QString &style){
		QFile qss(style);
		qss.open(QFile::ReadOnly);
		qApp->setStyleSheet(qss.readAll());
		qss.close();
	}
};
