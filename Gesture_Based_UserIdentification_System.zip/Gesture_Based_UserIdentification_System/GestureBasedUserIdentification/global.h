#ifndef GLOBAL_H
#define GLOBAL_H

#include <Windows.h>
#include <vector>
#include <fstream> 
#include <iostream>
#include <Windows.h>
#include <fstream> 
#include <string>
#include "Kinect\Kinect.h"
#include "OpenCV\opencv.hpp"
#include "FANN\doublefann.h"

#ifdef _DEBUG
#pragma comment(lib,"./Kinect/lib/Kinect20.lib")
#pragma comment(lib,"./OpenCV/lib/opencv_core249d.lib")
#pragma comment(lib,"./OpenCV/lib/opencv_imgproc249d.lib")
#pragma comment(lib,"./OpenCV/lib/opencv_highgui249d.lib")
#pragma comment(lib,"./OpenCV/lib/opencv_ml249d.lib")
#pragma comment(lib,"./OpenCV/lib/opencv_video249d.lib")
#pragma comment(lib,"./OpenCV/lib/opencv_features2d249d.lib")
#pragma comment(lib,"./OpenCV/lib/opencv_calib3d249d.lib")
#pragma comment(lib,"./OpenCV/lib/opencv_objdetect249d.lib")
#pragma comment(lib,"./OpenCV/lib/opencv_contrib249d.lib")
#pragma comment(lib,"./OpenCV/lib/opencv_legacy249d.lib")
#pragma comment(lib,"./OpenCV/lib/opencv_flann249d.lib")
#pragma comment(lib,"./FANN/lib/fanndouble.lib")
#pragma comment(lib,"./FANN/lib/fannfloat.lib")
#pragma comment(lib,"./FANN/lib/fannfixed.lib")
#else
#pragma comment(lib,"./Kinect/lib/Kinect20.lib")
#pragma comment(lib,"./OpenCV/lib/opencv_core249.lib")
#pragma comment(lib,"./OpenCV/lib/opencv_imgproc249.lib")
#pragma comment(lib,"./OpenCV/lib/opencv_highgui249.lib")
#pragma comment(lib,"./OpenCV/lib/opencv_ml249.lib")
#pragma comment(lib,"./OpenCV/lib/opencv_video249.lib")
#pragma comment(lib,"./OpenCV/lib/opencv_features2d249.lib")
#pragma comment(lib,"./OpenCV/lib/opencv_calib3d249.lib")
#pragma comment(lib,"./OpenCV/lib/opencv_objdetect249.lib")
#pragma comment(lib,"./OpenCV/lib/opencv_contrib249.lib")
#pragma comment(lib,"./OpenCV/lib/opencv_legacy249.lib")
#pragma comment(lib,"./OpenCV/lib/opencv_flann249.lib")
#pragma comment(lib,"./FANN/lib/fanndouble.lib")
#pragma comment(lib,"./FANN/lib/fannfloat.lib")
#pragma comment(lib,"./FANN/lib/fannfixed.lib")
#endif


#define USERNUM 6
#define GESTURENUM 3
#define TEMPLATENUM 3
#define IMAGE_WIDTH 640
#define IMAGE_HEIGHT 480



template<class Interface>
inline void SafeRelease(Interface *& pInterfaceToRelease){
	if (pInterfaceToRelease != NULL){
		pInterfaceToRelease->Release();
		pInterfaceToRelease = NULL;
	}
}

struct point3d{
	float x, y, z;
};
struct point2d{
	int x, y;
};


#endif