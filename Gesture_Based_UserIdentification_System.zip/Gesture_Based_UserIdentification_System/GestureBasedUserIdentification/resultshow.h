#ifndef RESULTSHOW_H
#define RESULTSHOW_H

#include <QWidget>
#include "ui_resultshow.h"
#include <qlabel.h>
#include <QMouseEvent> //���������ͷ�ļ�
#include <QPushButton> //���ð�ť��ͷ�ļ�

class ResultShow : public QWidget
{
	Q_OBJECT

public:
	ResultShow(QWidget *parent = 0);
	~ResultShow();

private:
	Ui::ResultShow ui;

private:
	QLabel *labelTitle;
	QLabel *labelMessage;
	QLabel *labelBottom;
	QLabel *labelLeft;
	QLabel *labelRight;
	QPushButton *buttonClose;
	QPoint last;
	QString resultWindName;

	void setLabelBottom();
	void setWindowStyle();
	void setLabelTitle();
	void setLabelMessage();
	void setButtonClose();

protected:
	//��갴��
	void mousePressEvent(QMouseEvent *e);
	//����ƶ�
	void mouseMoveEvent(QMouseEvent *e);
	//����ͷ�
	void mouseReleaseEvent(QMouseEvent *e);
	//���� QPoint ����
private slots:
	void refreshLableTitle();
};

#endif // RESULTSHOW_H
